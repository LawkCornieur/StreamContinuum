import os
import json
import xbmcaddon
import xbmcvfs
import re
import time
import xbmc
import datetime
import unicodedata
import threading

try:
    import tmdb
except Exception:
    tmdb = None

ADDON = xbmcaddon.Addon()
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
HISTORY_FILE = os.path.join(PROFILE_DIR, 'history.json')
TOMBSTONES_FILE = os.path.join(PROFILE_DIR, 'history_tombstones.json')
TOMBSTONE_EXPIRATION_DAYS = 30

_EPISODE_PATTERN = re.compile(
    r'^(.*?)(?:[\s._\-]+|(?<=[^\W\d_]))(?:S(\d+)\s*E(\d+)\b|\b(\d+)x(\d+)\b|\b(?:série|serie|season)\s*(\d+)\s*(?:epizoda|díl|dil|ep|e)\s*(\d+)\b)',
    re.IGNORECASE
)

_SERIES_DETECT_PATTERN = re.compile(
    r'(?:^|[\s._\-]|(?<=[^\W\d_]))(?:s\d+\s*e\d+\b|\bseason\s*\d+\b|\bsérie\s*\d+\b|\bserie\s*\d+\b|\bs\d+\b|\be\d+\b|\b\d+x\d+\b)',
    re.IGNORECASE
)

_VIDEO_EXT_PATTERN = re.compile(r'\.(mkv|avi|mp4|m4v|mov|wmv|ts|flv)$', re.IGNORECASE)


def _safe_timestamp(val):
    if not val:
        return 0
    try:
        return int(float(val))
    except (ValueError, TypeError):
        pass
    try:
        val_str = str(val).replace('T', ' ').strip()
        if len(val_str) >= 10:
            dt = datetime.datetime.fromisoformat(val_str[:19])
            return int(dt.timestamp())
    except Exception:
        pass
    return 0


def has_non_latin(s):
    if not s:
        return False
    for ch in str(s):
        o = ord(ch)
        if o > 0x024F and not (0x1E00 <= o <= 0x1EFF or 0x2000 <= o <= 0x206F):
            return True
    return False


def sanitize_title(s):
    if not s:
        return ""
    cleaned = []
    for ch in str(s):
        o = ord(ch)
        if o < 32 or (0x007F <= o <= 0x009F) or (0xD800 <= o <= 0xDFFF) or (0xFFF0 <= o <= 0xFFFF) or o >= 0x10000:
            continue
        cleaned.append(ch)
    return "".join(cleaned).strip()


def strip_diacritics(s):
    if not s:
        return ""
    norm = unicodedata.normalize('NFKD', str(s))
    return "".join(c for c in norm if not unicodedata.combining(c))


def is_series(query):
    if not query:
        return False
    return bool(_SERIES_DETECT_PATTERN.search(str(query)))


def parse_episode_info(query):
    """
    Vrátí n-tici (ws_base, season, episode, episode_code) z vyhledávacího dotazu.
    Pokud dotaz neobsahuje označení epizody, vrací (get_base_name(query), None, None, None).
    """
    if not query:
        return "", None, None, None
    q_str = str(query).strip()
    m = _EPISODE_PATTERN.search(q_str)
    if m:
        raw_base = (m.group(1) or "").strip()
        cleaned_base = re.sub(r'[\s._\-]+$', '', raw_base).strip()
        ws_base = get_base_name(cleaned_base) if cleaned_base else get_base_name(q_str)
        season = int(m.group(2) or m.group(4) or m.group(6))
        episode = int(m.group(3) or m.group(5) or m.group(7))
        ep_code = f"S{season:02d}E{episode:02d}"
        return ws_base, season, episode, ep_code
    return get_base_name(q_str), None, None, None


def get_base_name(query):
    if not query:
        return ""
    q = str(query)
    q = _VIDEO_EXT_PATTERN.sub('', q)
    q = re.sub(r'[._]', ' ', q)
    q = re.sub(r'(?:[\s._\-]+|(?<=[^\W\d_]))(?:s\d+\s*e\d+|\bseason\s*\d+|\bsérie\s*\d+|\bserie\s*\d+|\bs\d+\b|\be\d+\b|\b\d+x\d+\b).*$', '', q, flags=re.IGNORECASE).strip()
    q = re.sub(r'\b(2160p|1080p|720p|480p|4k|uhd|hd|hdtv|web-?dl|bluray|blu-?ray|bdrip|brrip|dvdrip|dvd|laserdisk|laserdisc|cd|vhs|remux|x264|x265|h264|hevc|aac|ac3|dts)\b.*$', '', q, flags=re.IGNORECASE).strip()
    q = re.sub(r'\b(cz|sk|en|de|czech|czdab|skdab|dabing|dab|czsub|sksub|sub|titulky|tit|cztit|sktit|repack|proper|extended|unrated)\b.*$', '', q, flags=re.IGNORECASE).strip()
    q = re.sub(r'\s*\(?\d{4}\)?$', '', q).strip()
    q = re.sub(r'[\-\–\—\s]+$', '', q).strip()
    q = re.sub(r'\s+', ' ', q).strip()
    return sanitize_title(q) if q else sanitize_title(str(query))


def normalize_match_key(s):
    if not s:
        return ""
    base = get_base_name(s)
    ascii_s = strip_diacritics(base).lower()
    ascii_s = re.sub(r'[:\-\–\—/\\|(),.!?\'\"]+', ' ', ascii_s)
    ascii_s = re.sub(r'\s+', ' ', ascii_s).strip()
    return ascii_s


def _clean_item_title(raw_title, query, tmdb_id):
    if not raw_title:
        return None
    t = sanitize_title(raw_title)
    if not t or has_non_latin(t):
        return None
    if not tmdb_id:
        if _VIDEO_EXT_PATTERN.search(t) or is_series(t):
            return None
        if query and t.strip().lower() == str(query).strip().lower():
            return None
    return t


def normalize_history_item(item, default_ts=None):
    if not isinstance(item, dict):
        return None
    if item.get('is_deleted'):
        return None
    raw_query = item.get('query')
    if not raw_query or not str(raw_query).strip():
        return None

    clean_query = str(raw_query).strip()
    now = default_ts or int(time.time())

    tmdb_id = item.get('tmdb_id')
    try:
        tmdb_id = int(tmdb_id) if (tmdb_id and str(tmdb_id).strip().lower() not in ('none', '', '0')) else None
    except (ValueError, TypeError):
        tmdb_id = None

    s_info = item.get('series_info') if isinstance(item.get('series_info'), dict) else {}
    ws_base, season, episode, ep_code = parse_episode_info(clean_query)
    if season is None and item.get('season') is not None:
        try:
            season = int(item.get('season'))
        except (ValueError, TypeError):
            season = None
    if episode is None and item.get('episode') is not None:
        try:
            episode = int(item.get('episode'))
        except (ValueError, TypeError):
            episode = None
    if season is None and s_info.get('season') is not None:
        try:
            season = int(s_info.get('season'))
        except (ValueError, TypeError):
            season = None
    if episode is None and s_info.get('episode') is not None:
        try:
            episode = int(s_info.get('episode'))
        except (ValueError, TypeError):
            episode = None

    if season is not None and episode is not None:
        ep_code = f"S{season:02d}E{episode:02d}"
    else:
        ep_code = None

    is_tv = (
        item.get('media_type') in ('tvshow', 'tv', 'show')
        or is_series(clean_query)
        or (season is not None and episode is not None)
    )
    media_type = 'tvshow' if is_tv else 'movie'

    if is_tv:
        saved_ws_base = item.get('ws_base') or s_info.get('ws_base')
        if saved_ws_base and str(saved_ws_base).strip():
            ws_base = get_base_name(saved_ws_base) or ws_base
        if season is not None and episode is not None and ws_base:
            clean_query = f"{ws_base} S{season:02d}E{episode:02d}"
    else:
        ws_base = get_base_name(clean_query)

    title = _clean_item_title(item.get('title'), raw_query, tmdb_id)

    year = item.get('year')
    try:
        year = int(str(year)[:4]) if year else None
    except (ValueError, TypeError):
        year = None

    rating = item.get('rating')
    try:
        rating = float(rating) if rating is not None else None
    except (ValueError, TypeError):
        rating = None

    runtime = item.get('runtime')
    try:
        runtime = int(runtime) if runtime is not None else None
    except (ValueError, TypeError):
        runtime = None

    genres = item.get('genres', [])
    if isinstance(genres, str):
        genres = [g.strip() for g in genres.split(',') if g.strip()]
    elif not isinstance(genres, list):
        genres = []

    added_at = _safe_timestamp(item.get('added_at')) or now
    last_played_at = _safe_timestamp(item.get('last_played_at')) or added_at
    updated_at = _safe_timestamp(item.get('updated_at')) or last_played_at
    identified_at = _safe_timestamp(item.get('identified_at')) or (now if tmdb_id else None)
    is_watched = bool(item.get('is_watched', True))

    watched_eps = []
    if is_tv:
        raw_we = s_info.get('watched_episodes') or item.get('watched_episodes') or []
        if isinstance(raw_we, list):
            for code in raw_we:
                if isinstance(code, str) and re.match(r'^S\d+E\d+$', code.strip(), re.IGNORECASE):
                    norm_c = code.strip().upper()
                    if norm_c not in watched_eps:
                        watched_eps.append(norm_c)
        if is_watched and ep_code and ep_code not in watched_eps:
            watched_eps.append(ep_code)

        last_w_s = s_info.get('last_watched_season')
        last_w_e = s_info.get('last_watched_episode')
        if is_watched and season is not None and episode is not None:
            last_w_s = season
            last_w_e = episode

        series_info_obj = {
            'ws_base': ws_base,
            'season': season,
            'episode': episode,
            'episode_code': ep_code,
            'last_watched_season': last_w_s,
            'last_watched_episode': last_w_e,
            'watched_episodes': sorted(watched_eps)
        }
    else:
        series_info_obj = None

    return {
        'query': clean_query,
        'title': title,
        'year': year,
        'plot': str(item.get('plot') or '') if item.get('plot') else '',
        'genres': genres,
        'rating': rating,
        'runtime': runtime,
        'poster': item.get('poster') or None,
        'fanart': item.get('fanart') or None,
        'tmdb_id': tmdb_id,
        'media_type': media_type,
        'ws_base': ws_base,
        'season': season if is_tv else None,
        'episode': episode if is_tv else None,
        'episode_code': ep_code if is_tv else None,
        'series_info': series_info_obj,
        'identified_at': identified_at,
        'is_watched': is_watched,
        'last_played_at': last_played_at,
        'updated_at': updated_at,
        'added_at': added_at,
        '_raw_title_hint': str(item.get('title') or '')
    }


def _extract_candidate_names(norm_item):
    names = set()
    for src in (norm_item.get('title'), norm_item.get('ws_base'), norm_item.get('query'), norm_item.get('_raw_title_hint')):
        if not src:
            continue
        k = normalize_match_key(src)
        if k and len(k) >= 2:
            names.add(k)
        raw_base = get_base_name(src)
        # Rozdělení složených názvů typu "Zakon gangu / Sons of Anarchy" nebo "Zákon gangu | Sons of Anarchy"
        # Dvojtečka (:) a pomlčky (-/–/—) se nesmí dělit, protože jsou legitimní součástí názvu a podtitulu!
        parts = re.split(r'\s*[/\\|]+\s*', raw_base)
        if len(parts) > 1:
            for part in parts:
                pk = normalize_match_key(part)
                if pk and len(pk) >= 2 and not pk.isdigit():
                    names.add(pk)

        # Alternativní názvy v závorkách typu "Zákon gangu (Sons of Anarchy)" nebo doplňky "(st ds9)"
        m = re.match(r'^(.*?)\s*[\(\[](.*?)[\)\]]\s*$', raw_base)
        if m:
            main_p = m.group(1).strip()
            paren_p = m.group(2).strip()
            k_main = normalize_match_key(main_p)
            if k_main and len(k_main) >= 2 and not k_main.isdigit():
                names.add(k_main)
            k_paren = normalize_match_key(paren_p)
            ignored_tags = {
                'cz', 'sk', 'en', 'de', 'fr', 'ru', 'pl', 'hu', 'it', 'es',
                'dab', 'dabing', 'tit', 'titulky', 'sub', 'subs', 'czdab', 'skdab', 'cztit', 'sktit'
            }
            if k_paren and len(k_paren) >= 2 and not k_paren.isdigit() and k_paren not in ignored_tags:
                names.add(k_paren)
    return names


def _merge_metadata(target, source):
    """Doplní chybějící TMDb metadata ze source do target."""
    if not source:
        return target
    for k in ['tmdb_id', 'title', 'year', 'plot', 'genres', 'rating', 'runtime', 'poster', 'fanart', 'identified_at']:
        t_val = target.get(k)
        s_val = source.get(k)
        if s_val is not None and s_val != '' and s_val != []:
            if t_val is None or t_val == '' or t_val == []:
                target[k] = s_val
    return target


def consolidate_history_items(raw_items):
    """
    Sjednotí, deduplikuje a strukturovaně seskupí položky historie a watchlistu.
    - Filmy: 1 záznam na film (nejnovější stav podle updated_at/last_played_at, zachování TMDb metadat).
    - Seriály: seskupení všech epizod téhož seriálu (podle tmdb_id i normalizovaných názvů/dotazů),
      sloučení stavu totožných epizod (SxxExx), zachování nejvyšší/nejnovější zhlédnuté epizody v historii
      a nejvýše jedné nezhlédnuté následující epizody (pokud je > poslední zhlédnutá epizoda a již byla vysílána).
    """
    if not raw_items or not isinstance(raw_items, list):
        return []

    now = int(time.time())
    current_year = datetime.date.today().year
    normalized = []
    for idx, it in enumerate(raw_items):
        n = normalize_history_item(it, default_ts=now - idx)
        if n:
            normalized.append(n)

    if not normalized:
        return []

    # Union-Find seskupení zvlášť pro seriály a pro filmy
    def _group_items(sub_list):
        n_len = len(sub_list)
        parent = list(range(n_len))
        root_tmdb = {}
        for i, it in enumerate(sub_list):
            tid = it.get('tmdb_id')
            try:
                tid = int(tid) if (tid and str(tid).strip().lower() not in ('none', '', '0')) else None
            except (ValueError, TypeError):
                tid = None
            root_tmdb[i] = tid

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                t_a = root_tmdb.get(ra)
                t_b = root_tmdb.get(rb)
                if t_a is not None and t_b is not None and t_a != t_b:
                    # Striktní ochrana: Různá autoritativní TMDb ID představují odlišná díla a nesmí být sloučena!
                    return False
                parent[rb] = ra
                root_tmdb[ra] = t_a if t_a is not None else t_b
                return True
            return False

        # 1. Spojení podle shodného TMDb ID
        tmdb_owner = {}
        for i, it in enumerate(sub_list):
            tid = root_tmdb.get(i)
            if tid:
                if tid in tmdb_owner:
                    union(tmdb_owner[tid], i)
                else:
                    tmdb_owner[tid] = i

        # 2. Spojení podle shody kandidátních názvů (např. varianty dotazů nebo dual-titles)
        name_owner = {}
        for i, it in enumerate(sub_list):
            c_names = _extract_candidate_names(it)
            for cn in c_names:
                if cn in name_owner:
                    union(name_owner[cn], i)
                else:
                    name_owner[cn] = i

        groups = {}
        for i, it in enumerate(sub_list):
            r = find(i)
            groups.setdefault(r, []).append(it)
        return list(groups.values())

    tv_items = [it for it in normalized if it.get('media_type') == 'tvshow']
    movie_items = [it for it in normalized if it.get('media_type') != 'tvshow']

    result_items = []

    # 1. Konsolidace filmů
    for m_group in _group_items(movie_items):
        # Seřadit podle (updated_at, last_played_at, is_watched) sestupně
        m_group.sort(
            key=lambda x: (
                _safe_timestamp(x.get('updated_at')),
                _safe_timestamp(x.get('last_played_at')),
                1 if x.get('is_watched', True) else 0,
                1 if x.get('tmdb_id') else 0
            ),
            reverse=True
        )
        winner = dict(m_group[0])
        for other in m_group[1:]:
            _merge_metadata(winner, other)
        winner.pop('_raw_title_hint', None)
        winner['series_info'] = None
        result_items.append(winner)

    # 2. Konsolidace seriálů
    for s_group in _group_items(tv_items):
        # Nejlepší metadata ze skupiny
        meta_template = {}
        identified_candidates = sorted(
            [x for x in s_group if x.get('tmdb_id')],
            key=lambda x: (
                1 if x.get('plot') else 0,
                1 if x.get('poster') else 0,
                _safe_timestamp(x.get('identified_at')),
                _safe_timestamp(x.get('updated_at'))
            ),
            reverse=True
        )
        for cand in identified_candidates + s_group:
            _merge_metadata(meta_template, cand)

        # Preferovaný čistý ws_base (z nejnovější ztotožněné nebo nejnovější položky)
        preferred_ws_base = None
        for cand in sorted(s_group, key=lambda x: (1 if x.get('tmdb_id') else 0, _safe_timestamp(x.get('updated_at'))), reverse=True):
            wb = cand.get('ws_base')
            if wb and not _VIDEO_EXT_PATTERN.search(wb):
                preferred_ws_base = wb
                break
        if not preferred_ws_base:
            preferred_ws_base = meta_template.get('title') or s_group[0].get('ws_base') or get_base_name(s_group[0].get('query', ''))

        # Seskupit podle epizody (season, episode)
        ep_map = {}
        all_watched_codes = set()
        for it in s_group:
            s_info = it.get('series_info') or {}
            for wc in s_info.get('watched_episodes', []):
                all_watched_codes.add(wc)
            s_num = it.get('season')
            e_num = it.get('episode')
            ep_key = (s_num if s_num is not None else 0, e_num if e_num is not None else 0)
            ep_map.setdefault(ep_key, []).append(it)

        consolidated_eps = {}
        for ep_key, ep_list in ep_map.items():
            # Pro stejnou epizodu vyhrává nejnovější updated_at; při shodě vyhrává is_watched=True
            ep_list.sort(
                key=lambda x: (
                    _safe_timestamp(x.get('updated_at')),
                    _safe_timestamp(x.get('last_played_at')),
                    1 if x.get('is_watched', True) else 0,
                    1 if x.get('tmdb_id') else 0
                ),
                reverse=True
            )
            ep_winner = dict(ep_list[0])
            for other_ep in ep_list[1:]:
                _merge_metadata(ep_winner, other_ep)
            _merge_metadata(ep_winner, meta_template)
            if ep_winner.get('is_watched', True) and ep_winner.get('episode_code'):
                all_watched_codes.add(ep_winner['episode_code'])
            consolidated_eps[ep_key] = ep_winner

        watched_eps = [ep for ep in consolidated_eps.values() if ep.get('is_watched', True)]
        unwatched_eps = [ep for ep in consolidated_eps.values() if not ep.get('is_watched', True)]

        best_watched = None
        max_w_tuple = (-1, -1)
        max_w_updated = 0
        if watched_eps:
            watched_eps.sort(
                key=lambda x: (
                    x.get('season') or 0,
                    x.get('episode') or 0,
                    _safe_timestamp(x.get('updated_at')),
                    _safe_timestamp(x.get('last_played_at'))
                ),
                reverse=True
            )
            best_watched = dict(watched_eps[0])
            for w_ep in watched_eps[1:]:
                _merge_metadata(best_watched, w_ep)
            max_w_tuple = (best_watched.get('season') or 0, best_watched.get('episode') or 0)
            max_w_updated = max(_safe_timestamp(x.get('updated_at')) for x in watched_eps)
            max_w_played = max(_safe_timestamp(x.get('last_played_at')) for x in watched_eps)
            best_watched['last_played_at'] = max_w_played
            best_watched['updated_at'] = max(max_w_updated, max_w_played)
            ws_b = best_watched.get('ws_base') or preferred_ws_base
            best_watched['ws_base'] = ws_b
            if best_watched.get('season') is not None and best_watched.get('episode') is not None and ws_b:
                best_watched['query'] = f"{ws_b} S{best_watched['season']:02d}E{best_watched['episode']:02d}"
            best_watched['series_info'] = {
                'ws_base': ws_b,
                'season': best_watched.get('season'),
                'episode': best_watched.get('episode'),
                'episode_code': best_watched.get('episode_code'),
                'last_watched_season': best_watched.get('season'),
                'last_watched_episode': best_watched.get('episode'),
                'watched_episodes': sorted(all_watched_codes)
            }
            best_watched.pop('_raw_title_hint', None)
            result_items.append(best_watched)

        # Nezhlédnutá epizoda (Watchlist): pouze pokud je > max_w_tuple a nemá budoucí rok vydání
        valid_unwatched = []
        for u_ep in unwatched_eps:
            u_tuple = (u_ep.get('season') or 0, u_ep.get('episode') or 0)
            u_year = u_ep.get('year')
            if u_year and isinstance(u_year, int) and u_year > current_year:
                continue
            if u_ep.get('episode_code') and u_ep.get('episode_code') in all_watched_codes:
                continue
            if best_watched is None or u_tuple > max_w_tuple:
                valid_unwatched.append(u_ep)

        if valid_unwatched:
            valid_unwatched.sort(
                key=lambda x: (
                    _safe_timestamp(x.get('updated_at')),
                    _safe_timestamp(x.get('last_played_at')),
                    x.get('season') or 0,
                    x.get('episode') or 0
                ),
                reverse=True
            )
            best_unwatched = dict(valid_unwatched[0])
            _merge_metadata(best_unwatched, meta_template)
            ws_b = best_unwatched.get('ws_base') or preferred_ws_base
            best_unwatched['ws_base'] = ws_b
            if best_unwatched.get('season') is not None and best_unwatched.get('episode') is not None and ws_b:
                best_unwatched['query'] = f"{ws_b} S{best_unwatched['season']:02d}E{best_unwatched['episode']:02d}"
            best_unwatched['series_info'] = {
                'ws_base': ws_b,
                'season': best_unwatched.get('season'),
                'episode': best_unwatched.get('episode'),
                'episode_code': best_unwatched.get('episode_code'),
                'last_watched_season': best_watched.get('season') if best_watched else None,
                'last_watched_episode': best_watched.get('episode') if best_watched else None,
                'watched_episodes': sorted(all_watched_codes)
            }
            best_unwatched.pop('_raw_title_hint', None)
            result_items.append(best_unwatched)

    result_items.sort(
        key=lambda x: max(
            _safe_timestamp(x.get('updated_at')),
            _safe_timestamp(x.get('last_played_at')),
            _safe_timestamp(x.get('added_at'))
        ),
        reverse=True
    )
    return result_items[:60]


def load_tombstones():
    """Načte lokálně uložené náhrobky ze souboru history_tombstones.json."""
    if not os.path.exists(TOMBSTONES_FILE):
        return []
    try:
        with open(TOMBSTONES_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, list):
                now = int(time.time())
                cutoff = now - (TOMBSTONE_EXPIRATION_DAYS * 86400)
                valid = []
                for t in data:
                    if isinstance(t, dict) and t.get('is_deleted') and _safe_timestamp(t.get('deleted_at')) > cutoff:
                        valid.append(t)
                return valid
    except Exception as e:
        xbmc.log(f"StreamContinuum History: Error loading tombstones: {e}", xbmc.LOGWARNING)
    return []


def save_tombstones(tombstones):
    """Uloží náhrobky do history_tombstones.json."""
    if not os.path.exists(PROFILE_DIR):
        try:
            os.makedirs(PROFILE_DIR)
        except Exception:
            pass
    try:
        temp_file = f"{TOMBSTONES_FILE}.{os.getpid()}.{threading.get_ident()}.tmp"
        with open(temp_file, 'w', encoding='utf-8') as f:
            json.dump(tombstones, f, ensure_ascii=False, indent=4)
        os.replace(temp_file, TOMBSTONES_FILE)
    except Exception as e:
        xbmc.log(f"StreamContinuum History: Error saving tombstones: {e}", xbmc.LOGWARNING)


def item_matches_tombstone(item, tombstone):
    """
    Ověří, zda daná položka historie odpovídá náhrobku smazání.
    Vrací True, pokud položka odpovídá náhrobku a její čas změny/přehrání <= tombstone.deleted_at.
    """
    if not isinstance(item, dict) or not isinstance(tombstone, dict):
        return False
    if not tombstone.get('is_deleted'):
        return False

    del_time = _safe_timestamp(tombstone.get('deleted_at'))
    if del_time <= 0:
        return False

    # Pokud byla položka přehrána nebo upravena PO čase smazání, náhrobek ji nesmí smazat (uživatel ji znovu vyhledal/přidal)
    item_time = max(
        _safe_timestamp(item.get('updated_at')),
        _safe_timestamp(item.get('last_played_at')),
        _safe_timestamp(item.get('added_at'))
    )
    if item_time > del_time:
        return False

    t_tmdb = tombstone.get('tmdb_id')
    try:
        t_tmdb = int(t_tmdb) if t_tmdb and str(t_tmdb).strip().lower() not in ('none', '', '0') else None
    except (ValueError, TypeError):
        t_tmdb = None

    i_tmdb = item.get('tmdb_id')
    try:
        i_tmdb = int(i_tmdb) if i_tmdb and str(i_tmdb).strip().lower() not in ('none', '', '0') else None
    except (ValueError, TypeError):
        i_tmdb = None

    if t_tmdb and i_tmdb:
        if t_tmdb == i_tmdb:
            return True
        return False

    # Klíče a normalizované názvy náhrobku
    t_keys = set(tombstone.get('match_keys') or [])
    t_del_q = tombstone.get('deleted_query') or tombstone.get('query') or ''
    if t_del_q:
        k = normalize_match_key(t_del_q)
        if k:
            t_keys.add(k)
    t_ws = tombstone.get('ws_base')
    if t_ws:
        k = normalize_match_key(t_ws)
        if k:
            t_keys.add(k)

    # Klíče položky
    i_keys = set(_extract_candidate_names(item))
    i_q = item.get('query') or ''
    if i_q:
        k = normalize_match_key(i_q)
        if k:
            i_keys.add(k)
    i_ws = item.get('ws_base')
    if i_ws:
        k = normalize_match_key(i_ws)
        if k:
            i_keys.add(k)

    # Přímá textová shoda původního query
    if t_del_q and i_q and str(t_del_q).strip().lower() == str(i_q).strip().lower():
        return True

    # Shoda v klíčích
    if t_keys and i_keys and bool(t_keys & i_keys):
        t_type = tombstone.get('media_type')
        i_type = item.get('media_type')
        if not t_type or not i_type or t_type == i_type:
            return True

    return False


def remove_matching_tombstones(item_or_query):
    """Odstraní náhrobek, pokud uživatel položku znovu přidal/přehrál."""
    tombstones = load_tombstones()
    if not tombstones:
        return
    norm_item = None
    if isinstance(item_or_query, dict):
        norm_item = item_or_query
    else:
        q_str = str(item_or_query).strip()
        ws_base, season, episode, _ = parse_episode_info(q_str)
        norm_item = {
            'query': q_str,
            'ws_base': ws_base,
            'media_type': 'tvshow' if is_series(q_str) or season is not None else 'movie'
        }

    item_keys = set(_extract_candidate_names(norm_item))
    if norm_item.get('query'):
        k = normalize_match_key(norm_item['query'])
        if k:
            item_keys.add(k)
    if norm_item.get('ws_base'):
        k = normalize_match_key(norm_item['ws_base'])
        if k:
            item_keys.add(k)

    item_tmdb = norm_item.get('tmdb_id')
    try:
        item_tmdb = int(item_tmdb) if item_tmdb and str(item_tmdb).strip().lower() not in ('none', '', '0') else None
    except (ValueError, TypeError):
        item_tmdb = None

    kept_tombstones = []
    changed = False
    for t in tombstones:
        t_tmdb = t.get('tmdb_id')
        try:
            t_tmdb = int(t_tmdb) if t_tmdb and str(t_tmdb).strip().lower() not in ('none', '', '0') else None
        except (ValueError, TypeError):
            t_tmdb = None

        matched = False
        if item_tmdb and t_tmdb and item_tmdb == t_tmdb:
            matched = True
        else:
            t_keys = set(t.get('match_keys') or [])
            if t.get('deleted_query'):
                k = normalize_match_key(t['deleted_query'])
                if k:
                    t_keys.add(k)
            if t.get('ws_base'):
                k = normalize_match_key(t['ws_base'])
                if k:
                    t_keys.add(k)
            if item_keys and t_keys and bool(item_keys & t_keys):
                t_type = t.get('media_type')
                i_type = norm_item.get('media_type')
                if not t_type or not i_type or t_type == i_type:
                    matched = True

        if matched:
            changed = True
        else:
            kept_tombstones.append(t)

    if changed:
        save_tombstones(kept_tombstones)


def merge_tombstones(list_a, list_b):
    """
    Sloučí dva seznamy náhrobků (např. lokální a vzdálený z Webshare),
    odstraní duplicity (ponechá nejnovější deleted_at) a vyfiltruje expirované.
    """
    now = int(time.time())
    cutoff = now - (TOMBSTONE_EXPIRATION_DAYS * 86400)
    all_raw = (list_a or []) + (list_b or [])
    merged_map = {}

    for t in all_raw:
        if not isinstance(t, dict) or not t.get('is_deleted'):
            continue
        del_at = _safe_timestamp(t.get('deleted_at'))
        if del_at <= cutoff:
            continue

        tmdb_id = t.get('tmdb_id')
        try:
            tmdb_id = int(tmdb_id) if tmdb_id and str(tmdb_id).strip().lower() not in ('none', '', '0') else None
        except (ValueError, TypeError):
            tmdb_id = None

        ws_base = normalize_match_key(t.get('ws_base') or '')
        del_q = normalize_match_key(t.get('deleted_query') or t.get('query') or '')
        m_type = t.get('media_type') or ''

        if tmdb_id:
            key = f"tmdb:{tmdb_id}"
        elif ws_base:
            key = f"ws:{m_type}:{ws_base}"
        elif del_q:
            key = f"q:{del_q}"
        else:
            continue

        if key in merged_map:
            existing = merged_map[key]
            if del_at > _safe_timestamp(existing.get('deleted_at')):
                all_keys = sorted(list(set((existing.get('match_keys') or []) + (t.get('match_keys') or []))))
                t_copy = dict(t)
                t_copy['match_keys'] = all_keys
                merged_map[key] = t_copy
            else:
                existing['match_keys'] = sorted(list(set((existing.get('match_keys') or []) + (t.get('match_keys') or []))))
        else:
            t_copy = dict(t)
            t_copy['match_keys'] = sorted(list(set(t_copy.get('match_keys') or [])))
            merged_map[key] = t_copy

    return list(merged_map.values())


def filter_items_by_tombstones(items, tombstones):
    """Vyfiltruje ze seznamu položek ty, které odpovídají platným náhrobkům."""
    if not items:
        return []
    if not tombstones:
        return [it for it in items if isinstance(it, dict) and not it.get('is_deleted')]
    alive = []
    for item in items:
        if not isinstance(item, dict) or item.get('is_deleted'):
            continue
        deleted = False
        for t in tombstones:
            if item_matches_tombstone(item, t):
                deleted = True
                break
        if not deleted:
            alive.append(item)
    return alive


def get_history(deduplicate=True):
    if not os.path.exists(PROFILE_DIR):
        try:
            os.makedirs(PROFILE_DIR)
        except Exception:
            pass
    if not os.path.exists(HISTORY_FILE):
        return []
    try:
        with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
            items = json.load(f)
            if not isinstance(items, list):
                return []
            raw_active = [it for it in items if isinstance(it, dict) and not it.get('is_deleted') and str(it.get('query', '')).strip()]
            if not deduplicate:
                now = int(time.time())
                norm_list = []
                for idx, it in enumerate(raw_active):
                    n = normalize_history_item(it, default_ts=now - idx)
                    if n:
                        n.pop('_raw_title_hint', None)
                        norm_list.append(n)
                norm_list.sort(
                    key=lambda x: max(
                        _safe_timestamp(x.get('updated_at')),
                        _safe_timestamp(x.get('last_played_at')),
                        _safe_timestamp(x.get('added_at'))
                    ),
                    reverse=True
                )
                return norm_list
            return consolidate_history_items(raw_active)
    except json.JSONDecodeError as jde:
        xbmc.log(f"StreamContinuum History: Corrupted history.json detected: {jde}", xbmc.LOGERROR)
        try:
            bak_file = HISTORY_FILE + '.corrupted'
            if os.path.exists(HISTORY_FILE):
                os.replace(HISTORY_FILE, bak_file)
        except Exception:
            pass
        return []
    except Exception as e:
        xbmc.log(f"StreamContinuum History: Error loading history.json: {e}", xbmc.LOGERROR)
        return []


def get_history_item(query):
    if not query:
        return None
    items = get_history(deduplicate=True)
    norm_q = str(query).strip().lower()
    for item in items:
        if item.get('query') == query or str(item.get('query', '')).strip().lower() == norm_q:
            return item
    q_match = normalize_match_key(query)
    if q_match:
        for item in items:
            item_q = item.get('query', '')
            if normalize_match_key(item_q) == q_match or q_match in _extract_candidate_names(item):
                return item
    return None


def _save_history(history_list, tombstones=None):
    try:
        if not os.path.exists(PROFILE_DIR):
            try:
                os.makedirs(PROFILE_DIR)
            except Exception:
                pass
        current_tombstones = load_tombstones()
        if tombstones:
            current_tombstones = merge_tombstones(current_tombstones, tombstones)
            save_tombstones(current_tombstones)

        raw_active = [it for it in (history_list or []) if isinstance(it, dict) and not it.get('is_deleted') and str(it.get('query', '')).strip()]
        filtered = filter_items_by_tombstones(raw_active, current_tombstones)
        consolidated = consolidate_history_items(filtered)

        full_output = consolidated + current_tombstones
        temp_file = f"{HISTORY_FILE}.{os.getpid()}.{threading.get_ident()}.tmp"
        with open(temp_file, 'w', encoding='utf-8') as f:
            json.dump(full_output, f, ensure_ascii=False, indent=4)
        os.replace(temp_file, HISTORY_FILE)
    except Exception as e:
        xbmc.log(f"StreamContinuum History: Error saving history.json: {e}", xbmc.LOGERROR)


def add_to_history(query):
    if not query:
        return
    query_str = str(query).strip()
    remove_matching_tombstones(query_str)
    history_items = get_history(deduplicate=True)
    now = int(time.time())
    ws_base, season, episode, ep_code = parse_episode_info(query_str)
    query_is_series = is_series(query_str) or (season is not None and episode is not None)

    new_item = {
        'query': query_str,
        'title': None,
        'year': None,
        'plot': '',
        'genres': [],
        'rating': None,
        'runtime': None,
        'poster': None,
        'fanart': None,
        'tmdb_id': None,
        'media_type': 'tvshow' if query_is_series else 'movie',
        'ws_base': ws_base,
        'season': season if query_is_series else None,
        'episode': episode if query_is_series else None,
        'episode_code': ep_code if query_is_series else None,
        'identified_at': None,
        'is_watched': True,
        'last_played_at': now,
        'updated_at': now,
        'added_at': now
    }

    history_items.insert(0, new_item)
    _save_history(history_items)


def add_to_watchlist_local(query, tmdb_data=None):
    if not query:
        return
    query_str = str(query).strip()
    remove_matching_tombstones(query_str)
    history_items = get_history(deduplicate=True)
    now = int(time.time())
    ws_base, season, episode, ep_code = parse_episode_info(query_str)
    query_is_series = is_series(query_str) or (tmdb_data and tmdb_data.get('media_type') in ('tvshow', 'tv', 'show')) or (season is not None and episode is not None)

    item_to_add = {
        'query': query_str,
        'title': sanitize_title(tmdb_data.get('title')) if (tmdb_data and tmdb_data.get('title')) else None,
        'year': tmdb_data.get('year') if tmdb_data else None,
        'plot': tmdb_data.get('plot', '') if tmdb_data else '',
        'genres': tmdb_data.get('genres', []) if tmdb_data else [],
        'rating': tmdb_data.get('rating') if tmdb_data else None,
        'runtime': tmdb_data.get('runtime') if tmdb_data else None,
        'poster': tmdb_data.get('poster') if tmdb_data else None,
        'fanart': tmdb_data.get('fanart') if tmdb_data else None,
        'tmdb_id': tmdb_data.get('tmdb_id') if tmdb_data else None,
        'media_type': tmdb_data.get('media_type') if (tmdb_data and tmdb_data.get('media_type')) else ('tvshow' if query_is_series else 'movie'),
        'ws_base': ws_base,
        'season': season if query_is_series else None,
        'episode': episode if query_is_series else None,
        'episode_code': ep_code if query_is_series else None,
        'identified_at': now if (tmdb_data and tmdb_data.get('tmdb_id')) else None,
        'is_watched': False,
        'last_played_at': now,
        'updated_at': now,
        'added_at': now
    }

    history_items.insert(0, item_to_add)
    _save_history(history_items)


def set_watched_status(query, is_watched):
    if not query:
        return False
    history_items = get_history(deduplicate=True)
    now = int(time.time())
    norm_q = str(query).strip().lower()
    q_match = normalize_match_key(query)
    _, q_season, q_episode, q_ep_code = parse_episode_info(query)
    q_is_tv = is_series(query) or (q_season is not None and q_episode is not None)

    target_tmdb_id = None
    exact_matched = False
    for it in history_items:
        it_q = str(it.get('query', '')).strip().lower()
        if it_q == norm_q or (q_ep_code and it.get('episode_code') == q_ep_code and normalize_match_key(it_q) == q_match):
            target_tmdb_id = it.get('tmdb_id')
            it['is_watched'] = bool(is_watched)
            it['updated_at'] = now
            if is_watched:
                it['last_played_at'] = now
            else:
                # Pokud uživatel ručně odznačil epizodu jako nezhlédnutou, odebrat ji ze seznamu watched_episodes
                s_info = it.get('series_info')
                if isinstance(s_info, dict) and q_ep_code and q_ep_code in s_info.get('watched_episodes', []):
                    s_info['watched_episodes'] = [c for c in s_info['watched_episodes'] if c != q_ep_code]
            exact_matched = True

    updated = exact_matched
    if not exact_matched:
        for item in history_items:
            item_query = str(item.get('query', '')).strip().lower()
            item_match = normalize_match_key(item_query)
            item_is_tv = item.get('media_type') in ('tvshow', 'tv', 'show') or is_series(item_query)
            item_tmdb_id = item.get('tmdb_id')

            matches = (item_query == norm_q)
            if not matches:
                if target_tmdb_id and item_tmdb_id:
                    matches = (target_tmdb_id == item_tmdb_id)
                elif q_match and item_match and q_match == item_match and (q_is_tv == item_is_tv):
                    matches = True

            if matches:
                item['is_watched'] = bool(is_watched)
                item['updated_at'] = now
                if is_watched:
                    item['last_played_at'] = now
                updated = True

    if updated:
        _save_history(history_items)
    return updated


def delete_from_history(query):
    if not query:
        return
    query_str = str(query).strip()
    norm_q = query_str.lower()

    # 1. Zjistit cíl a metadata
    target_item = get_history_item(query_str)
    q_ws_base, q_season, q_episode, _ = parse_episode_info(query_str)

    target_tmdb_id = target_item.get('tmdb_id') if target_item else None
    try:
        target_tmdb_id = int(target_tmdb_id) if target_tmdb_id and str(target_tmdb_id).strip().lower() not in ('none', '', '0') else None
    except (ValueError, TypeError):
        target_tmdb_id = None

    target_media_type = (target_item.get('media_type') if target_item else None) or ('tvshow' if is_series(query_str) or q_season is not None else 'movie')
    target_ws_base = (target_item.get('ws_base') if target_item else None) or q_ws_base or get_base_name(query_str)

    target_keys = set()
    if target_item:
        target_keys.update(_extract_candidate_names(target_item))
    if query_str:
        k = normalize_match_key(query_str)
        if k:
            target_keys.add(k)
    if target_ws_base:
        k = normalize_match_key(target_ws_base)
        if k:
            target_keys.add(k)

    # 2. Načíst všechny surové položky z HISTORY_FILE
    raw_items = []
    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                loaded = json.load(f)
                if isinstance(loaded, list):
                    raw_items = loaded
        except Exception as e:
            xbmc.log(f"StreamContinuum History: Error reading history file in delete_from_history: {e}", xbmc.LOGWARNING)
            raw_items = []

    remaining_items = []
    for item in raw_items:
        if not isinstance(item, dict):
            continue
        if item.get('is_deleted'):
            continue

        it_q = str(item.get('query', '')).strip()
        norm_it_q = it_q.lower()
        it_tmdb = item.get('tmdb_id')
        try:
            it_tmdb = int(it_tmdb) if it_tmdb and str(it_tmdb).strip().lower() not in ('none', '', '0') else None
        except (ValueError, TypeError):
            it_tmdb = None

        it_type = item.get('media_type')
        it_ws = item.get('ws_base') or get_base_name(it_q)

        matches = False
        if norm_it_q == norm_q:
            matches = True
        elif target_tmdb_id and it_tmdb:
            matches = (target_tmdb_id == it_tmdb)
        elif (target_media_type == 'tvshow' or it_type == 'tvshow' or is_series(it_q) or is_series(query_str)):
            if target_ws_base and it_ws and normalize_match_key(target_ws_base) == normalize_match_key(it_ws):
                matches = True
            elif target_keys and bool(target_keys & set(_extract_candidate_names(item))):
                matches = True
            elif normalize_match_key(it_q) and normalize_match_key(query_str) and normalize_match_key(it_q) == normalize_match_key(query_str):
                matches = True
        else:
            if target_keys and bool(target_keys & set(_extract_candidate_names(item))):
                matches = True
            elif normalize_match_key(it_q) and normalize_match_key(query_str) and normalize_match_key(it_q) == normalize_match_key(query_str):
                matches = True

        if not matches:
            remaining_items.append(item)

    # 3. Zaznamenat náhrobek
    now = int(time.time())
    new_tombstone = {
        'is_deleted': True,
        'deleted_at': now,
        'query': '',
        'deleted_query': query_str,
        'ws_base': target_ws_base or get_base_name(query_str),
        'tmdb_id': target_tmdb_id,
        'media_type': target_media_type,
        'match_keys': sorted(list(target_keys))
    }

    current_tombstones = load_tombstones()
    updated_tombstones = merge_tombstones(current_tombstones, [new_tombstone])
    save_tombstones(updated_tombstones)

    # 4. Uložit pročištěnou historii včetně náhrobků
    _save_history(remaining_items, tombstones=updated_tombstones)
    xbmc.log(f"StreamContinuum History: Deleted '{query_str}' from history (recorded tombstone at {now})", xbmc.LOGINFO)


def update_history_item(old_query, new_query):
    if not old_query or not new_query:
        return
    remove_matching_tombstones(new_query)
    history_items = get_history(deduplicate=True)
    now = int(time.time())
    norm_old = str(old_query).strip().lower()
    old_match = normalize_match_key(old_query)
    ws_base, season, episode, ep_code = parse_episode_info(new_query)

    updated = False
    for item in history_items:
        item_q = str(item.get('query', '')).strip()
        if item_q == str(old_query).strip() or item_q.lower() == norm_old or (old_match and normalize_match_key(item_q) == old_match):
            item['query'] = new_query
            item['ws_base'] = ws_base
            item['season'] = season
            item['episode'] = episode
            item['episode_code'] = ep_code
            item['last_played_at'] = now
            item['updated_at'] = now
            updated = True
            break
    if updated:
        _save_history(history_items)


def update_history_with_tmdb_data(original_query, tmdb_data):
    if not original_query:
        return False
    history_items = get_history(deduplicate=True)
    updated = False
    now = int(time.time())
    norm_orig = str(original_query).strip().lower()
    orig_match = normalize_match_key(original_query)
    orig_base = get_base_name(original_query).strip()

    clean_title = sanitize_title(tmdb_data.get('title'))
    if has_non_latin(clean_title) or not clean_title:
        clean_title = orig_base or original_query

    for item in history_items:
        item_query = str(item.get('query', '')).strip().lower()
        item_match = normalize_match_key(item.get('query', ''))
        if item_query == norm_orig or str(item.get('query', '')).strip() == str(original_query).strip() or (orig_match and item_match == orig_match):
            item['title'] = clean_title
            item['year'] = tmdb_data.get('year')
            item['plot'] = tmdb_data.get('plot')
            item['genres'] = tmdb_data.get('genres', [])
            item['rating'] = tmdb_data.get('rating')
            item['runtime'] = tmdb_data.get('runtime')
            item['poster'] = tmdb_data.get('poster')
            item['fanart'] = tmdb_data.get('fanart')
            item['tmdb_id'] = tmdb_data.get('tmdb_id')
            item['media_type'] = tmdb_data.get('media_type')
            item['identified_at'] = now
            item['updated_at'] = now
            updated = True

    if not updated and original_query:
        ws_base, season, episode, ep_code = parse_episode_info(original_query)
        new_item = {
            'query': original_query,
            'title': clean_title,
            'year': tmdb_data.get('year'),
            'plot': tmdb_data.get('plot'),
            'genres': tmdb_data.get('genres', []),
            'rating': tmdb_data.get('rating'),
            'runtime': tmdb_data.get('runtime'),
            'poster': tmdb_data.get('poster'),
            'fanart': tmdb_data.get('fanart'),
            'tmdb_id': tmdb_data.get('tmdb_id'),
            'media_type': tmdb_data.get('media_type'),
            'ws_base': ws_base,
            'season': season,
            'episode': episode,
            'episode_code': ep_code,
            'identified_at': now,
            'is_watched': True,
            'last_played_at': now,
            'updated_at': now,
            'added_at': now
        }
        history_items.insert(0, new_item)
        updated = True
    if updated:
        _save_history(history_items)
    return updated


def check_and_update_next_episodes():
    if tmdb is None:
        return False
    try:
        all_items = get_history(deduplicate=True)
        if not all_items:
            return False

        # Mapa seriálů, které už mají nezhlédnutou epizodu ve Watchlistu
        unwatched_series_keys = set()
        for item in all_items:
            if item.get('media_type') == 'tvshow' and not item.get('is_watched', True):
                if item.get('tmdb_id'):
                    unwatched_series_keys.add(f"tmdb:{item.get('tmdb_id')}")
                wb = normalize_match_key(item.get('ws_base') or item.get('query'))
                if wb:
                    unwatched_series_keys.add(f"name:{wb}")

        today = datetime.date.today()
        updated_any = False
        items_modified_meta = False

        for item in all_items:
            if item.get('media_type') != 'tvshow' or not item.get('is_watched', True):
                continue

            last_s = item.get('season')
            last_e = item.get('episode')
            if last_s is None or last_e is None:
                continue

            ws_base = item.get('ws_base') or get_base_name(item.get('query', ''))
            tmdb_id = item.get('tmdb_id')
            s_key_tmdb = f"tmdb:{tmdb_id}" if tmdb_id else None
            s_key_name = f"name:{normalize_match_key(ws_base)}" if ws_base else None

            if (s_key_tmdb and s_key_tmdb in unwatched_series_keys) or (s_key_name and s_key_name in unwatched_series_keys):
                continue

            if not tmdb_id:
                search_title = item.get('title') or ws_base
                if search_title:
                    try:
                        res = tmdb.search_tmdb(search_title)
                        for r in res:
                            if r.get('type') == 'show' and r.get('id'):
                                tmdb_id = r.get('id')
                                item['tmdb_id'] = tmdb_id
                                item['identified_at'] = int(time.time())
                                if r.get('clean_title') or r.get('title'):
                                    ct = sanitize_title(r.get('clean_title') or r.get('title'))
                                    if ct and not has_non_latin(ct):
                                        item['title'] = ct
                                items_modified_meta = True
                                _save_history(all_items)
                                break
                    except Exception:
                        pass

            if not tmdb_id:
                continue

            try:
                show_details = tmdb.get_show_seasons(tmdb_id)
                if not show_details or 'seasons' not in show_details:
                    continue

                curr_season_eps = tmdb.get_season_episodes(tmdb_id, last_s) or []
                next_ep_obj = next((e for e in curr_season_eps if e.get('episode_number') == last_e + 1), None)
                target_season = last_s
                target_episode = last_e + 1

                if not next_ep_obj:
                    next_season_obj = next((s for s in show_details.get('seasons', []) if s.get('season_number') == last_s + 1), None)
                    if next_season_obj:
                        next_season_eps = tmdb.get_season_episodes(tmdb_id, last_s + 1) or []
                        next_ep_obj = next((e for e in next_season_eps if e.get('episode_number') == 1), None)
                        target_season = last_s + 1
                        target_episode = 1

                if next_ep_obj:
                    air_date_str = next_ep_obj.get('air_date')
                    # Epizoda je vysílána POUZE pokud má platné datum vysílání <= dnes
                    is_aired = False
                    if air_date_str and len(str(air_date_str).strip()) >= 10:
                        try:
                            air_dt = datetime.datetime.strptime(str(air_date_str).strip()[:10], '%Y-%m-%d').date()
                            if air_dt <= today:
                                is_aired = True
                        except Exception:
                            is_aired = False

                    target_code = f"S{target_season:02d}E{target_episode:02d}"
                    watched_codes = (item.get('series_info') or {}).get('watched_episodes', [])
                    if is_aired and target_code not in watched_codes:
                        next_query = f"{ws_base} {target_code}"
                        full_show_title = show_details.get('title') or item.get('title') or ws_base
                        plot_text = next_ep_obj.get('overview') or show_details.get('overview') or ''
                        ep_runtime = next_ep_obj.get('runtime') or show_details.get('runtime') or item.get('runtime')
                        tmdb_data = {
                            'tmdb_id': tmdb_id,
                            'media_type': 'tvshow',
                            'title': full_show_title,
                            'year': int(str(air_date_str)[:4]) if (air_date_str and len(str(air_date_str)) >= 4) else show_details.get('year'),
                            'plot': plot_text,
                            'poster': show_details.get('poster') or item.get('poster'),
                            'fanart': show_details.get('fanart') or item.get('fanart'),
                            'rating': next_ep_obj.get('rating') or show_details.get('rating'),
                            'runtime': ep_runtime,
                            'genres': show_details.get('genres', [])
                        }
                        add_to_watchlist_local(next_query, tmdb_data)
                        updated_any = True
            except Exception as check_e:
                xbmc.log(f"StreamContinuum History: Error checking next episode for {ws_base}: {check_e}", xbmc.LOGWARNING)

        return updated_any
    except Exception as e:
        xbmc.log(f"StreamContinuum History: check_and_update_next_episodes failed: {e}", xbmc.LOGERROR)
        return False


def clear_history():
    if os.path.exists(HISTORY_FILE):
        try:
            os.remove(HISTORY_FILE)
            xbmc.log(f"StreamContinuum History: Cleared history file: {HISTORY_FILE}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"StreamContinuum History: Error clearing history file: {e}", xbmc.LOGERROR)
    if os.path.exists(TOMBSTONES_FILE):
        try:
            os.remove(TOMBSTONES_FILE)
            xbmc.log(f"StreamContinuum History: Cleared tombstones file: {TOMBSTONES_FILE}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"StreamContinuum History: Error clearing tombstones file: {e}", xbmc.LOGERROR)

